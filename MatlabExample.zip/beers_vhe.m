%%image parameters
xpix=2048;
ypix=2048;

%% colors to remap to
eosin = [.90 .9 .95]; % HSV vals for eosin color mapping
nuclei = [0.65 .70 1];% HSV vals for hematoxylin color mapping
k_mapping = 2.5;      % mapping coefficient between attenuation and LCD monitor dynamic range


%% Generating color mapping to HE
whiteBg = ones(xpix, ypix, 3);
collagenColor = hsv2rgb(cat(3, (eosin(1)-0.5) * ones(xpix, ypix), (eosin(2)) * ones(xpix, ypix), eosin(3)*ones(xpix, ypix)));
nucleiColor = hsv2rgb(cat(3, (nuclei(1)-0.5) * ones(xpix, ypix), (nuclei(2)) * ones(xpix, ypix), (nuclei(3))*ones(xpix, ypix)));

%%load the raw data file
path = 'Raw_00570.bin'
f=fopen(path);
btmp = fread(f,xpix*ypix*2,'uint16=>uint16');
data = im2double(reshape(btmp,xpix,ypix,2))*8;
fclose(f);

raw = data;
raw(:,:,3) = zeros(xpix,ypix);
figure;imagesc(raw);axis equal

%%do remapping
kTemp = blend_beers(whiteBg, collagenColor, data(:,:,2), k_mapping);
kTemp = blend_beers(kTemp, nucleiColor, data(:,:,1), k_mapping);

figure;imagesc(kTemp);axis equal


function r = blend_beers(bg, hue, signal, k)

r =bg./(1-exp(-k)).*(exp(-k.*cat(3, signal, signal, signal) .* hue )-exp(-k));

end
